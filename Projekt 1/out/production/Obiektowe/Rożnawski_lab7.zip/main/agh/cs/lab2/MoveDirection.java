package agh.cs.lab2;

public enum MoveDirection {
    FORWARD, BACKWARD, RIGHT, LEFT;
}
