package agh.cs.lab5;

import agh.cs.lab2.*;
import agh.cs.lab7.MapBoundary;

import java.util.Hashtable;
import java.util.Random;

import java.lang.Math;
import java.util.ArrayList;

public class GrassField extends AbstractWorldMap {

    protected Hashtable<Vector2d, Grass> grassMap;
    protected ArrayList<Grass> tufts;

    public GrassField(int number){
        upperright = lowerleft = new Vector2d(0,0);
        int round = (int) Math.round(Math.sqrt(10 * number))+1;
        grassMap = new Hashtable<>();
        this.animalMap = new Hashtable<>();
        animals = new Hashtable<>();
        tufts = new ArrayList<Grass>();
        Random rand = new Random();
        for(int i=0; i<number; i++){
            Vector2d newPosition = new Vector2d(rand.nextInt(round), rand.nextInt(round));
            while(isOccupied(newPosition)) newPosition = new Vector2d(rand.nextInt(round), rand.nextInt(round));
            Grass newGrass = new Grass(newPosition);
            grassMap.put(newPosition, newGrass);
            tufts.add(newGrass);
            mapBoundary.add(newGrass);
        }
        setBounds();
    }

    protected void setBounds(){
        upperright = mapBoundary.comptUpperRight();
        lowerleft = mapBoundary.comptLowerLeft();
    }

    public boolean place(Animal animal){
        if(canMoveTo(animal.getPosition())){
            animals.put(animal.getPosition(), animal);
            this.animalMap.put(animal.getPosition(), animal);
            mapBoundary.add(animal);
            setBounds();
            return true;
        }
        throw new IllegalArgumentException("Field "+animal.getPosition()+" is already occupied");
    }

    public void moveAnimal(Animal animal, MoveDirection direction){
        Vector2d oldPosition = animal.getPosition();
        animalMap.remove(animal.getPosition(), animal);
        animal.move(direction);
        animalMap.put(animal.getPosition(), animal);
        mapBoundary.positionChanged(oldPosition, animal.getPosition());
        System.out.println(animalMap.values());
        setBounds();
    }

    public boolean isOccupied(Vector2d position){
        if(!(position.precedes(upperright) && position.follows(lowerleft))) return false;
        return(animalMap.get(position) != null || grassMap.get(position) != null);
    }

    public Object objectAt(Vector2d position){
        Object whoAt = animalMap.get(position);
        if(whoAt != null) return whoAt;
        return grassMap.get(position);
    }

    public boolean canMoveTo(Vector2d position){
        return objectAt(position) == null || objectAt(position).getClass() == Grass.class ;
    }
}