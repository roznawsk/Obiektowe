package agh.cs.lab5;

import agh.cs.lab2.*;
import agh.cs.lab7.IPositionChangeObserver;
import agh.cs.lab7.MapBoundary;

import java.util.*;

abstract class AbstractWorldMap implements IWorldMap, IPositionChangeObserver {
    protected Vector2d lowerleft;
    protected Vector2d upperright;
    protected MapBoundary mapBoundary = new MapBoundary();

    protected Hashtable<Vector2d, Animal> animalMap;
    protected Hashtable<Vector2d, Animal> animals;

    public Collection<Animal> getAnimals(){
        return (Collection<Animal>) animals.elements();
    }

    public abstract boolean place(Animal animal);

    public abstract void moveAnimal(Animal animal, MoveDirection direction);

    public void positionChanged(Vector2d oldPosition, Vector2d newPosition){
        Animal animal = animalMap.get(oldPosition);
        animalMap.remove(oldPosition);
        animals.remove(oldPosition);
        animals.put(oldPosition, animal);
        animalMap.put(newPosition, animal);
    }

    public String toString(){
        MapVisualizer picture = new MapVisualizer(this);
        return  picture.draw(lowerleft, upperright);
    }

    public void run(MoveDirection[] directions){
        for(int i=0, a=0;i<directions.length;i++, a++, a%=animals.size()){
            moveAnimal(animals.get(a), directions[i]);
        }
    }


}
