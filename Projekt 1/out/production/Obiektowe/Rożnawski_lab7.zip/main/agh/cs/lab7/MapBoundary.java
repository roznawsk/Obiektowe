package agh.cs.lab7;

import agh.cs.lab2.Animal;
import agh.cs.lab2.Vector2d;
import agh.cs.lab5.Grass;
import agh.cs.lab7.IPositionChangeObserver;

import java.util.*;

public class MapBoundary implements IPositionChangeObserver {
    private final TreeSet<AbstractWorldElement> sortedByX = new TreeSet<>((v1, v2) -> v1.compareToX(v2));
    private final TreeSet<AbstractWorldElement> sortedByY = new TreeSet<>((v1, v2) -> v1.compareToY(v2));

    @Override
    public void positionChanged(Vector2d oldPosition, Vector2d newPosition) {
        if(!oldPosition.equals(newPosition))
            return;
        AbstractWorldElement prev = sortedByX.lower(new Animal(null, oldPosition));
        AbstractWorldElement next = sortedByX.higher(new Animal(null, oldPosition));
        if((prev != null || prev.getPosition().x >= newPosition.x) && (next != null || next.getPosition().x <= newPosition.x)){
            sortedByX.remove(new Animal(null, oldPosition));
            sortedByX.add(new Animal(null, newPosition));
        }
        prev = sortedByY.lower(new Animal(null, oldPosition));
        next = sortedByY.higher(new Animal(null, oldPosition));
        if((prev != null || prev.getPosition().y >= newPosition.y) && (next != null || next.getPosition().y <= newPosition.y)){
            sortedByY.remove(new Animal(null, oldPosition));
            sortedByY.add(new Animal(null, newPosition));
        }

    }

    public Vector2d comptUpperRight() {
        return new Vector2d(sortedByX.last().getPosition().x, sortedByY.last().getPosition().y);
    }

    public Vector2d comptLowerLeft(){
        return new Vector2d(sortedByX.first().getPosition().x, sortedByY.first().getPosition().y);
    }

    public void add(AbstractWorldElement e) {
        AbstractWorldElement entity;
        if(e instanceof Grass)
            entity = new Grass(e.getPosition());
        else
            entity = new Animal(null, e.getPosition());
        sortedByX.add(entity);
        sortedByY.add(entity);
    }

    public void remove(AbstractWorldElement e){
        sortedByX.remove(e);
        sortedByY.remove(e);
    }
}