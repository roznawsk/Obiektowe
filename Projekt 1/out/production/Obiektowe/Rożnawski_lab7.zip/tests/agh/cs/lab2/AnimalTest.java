package agh.cs.lab2;

import agh.cs.lab5.GrassField;
import agh.cs.lab5.RectangularMap;
import agh.cs.lab7.IPositionChangeObserver;
import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class AnimalTest {

    @Test
    public void testToString() {
        RectangularMap testmap = new RectangularMap(4,4);
        Animal rat = new Animal(testmap);
        Assert.assertEquals("^", rat.toString());
    }

    @Test
    public void move() {
        RectangularMap testmap = new RectangularMap(5,5);
        Animal rat = new Animal(testmap, new Vector2d(2,2));
        assertEquals(MapDirection.NORTH, rat.getDirection());
        Assert.assertEquals(new Vector2d(2,2), rat.getPosition());
        rat.move(MoveDirection.LEFT);
        assertEquals(MapDirection.WEST, rat.getDirection());
        Assert.assertEquals(new Vector2d(2,2), rat.getPosition());
        rat.move(MoveDirection.FORWARD);
        assertEquals(MapDirection.WEST, rat.getDirection());
        Assert.assertEquals(new Vector2d(1,2), rat.getPosition());
        rat.move(MoveDirection.FORWARD);
        assertEquals(MapDirection.WEST, rat.getDirection());
        Assert.assertEquals(new Vector2d(0,2), rat.getPosition());
        rat.move(MoveDirection.FORWARD);
        assertEquals(MapDirection.WEST, rat.getDirection());
        Assert.assertEquals(new Vector2d(0,2), rat.getPosition());
        rat.move(MoveDirection.RIGHT);
        assertEquals(MapDirection.NORTH, rat.getDirection());
        Assert.assertEquals(new Vector2d(0,2), rat.getPosition());
        rat.move(MoveDirection.FORWARD);
        assertEquals(MapDirection.NORTH, rat.getDirection());
        Assert.assertEquals(new Vector2d(0,3), rat.getPosition());
        rat.move(MoveDirection.FORWARD);
        assertEquals(MapDirection.NORTH, rat.getDirection());
        Assert.assertEquals(new Vector2d(0,4), rat.getPosition());
        rat.move(MoveDirection.FORWARD);
        assertEquals(MapDirection.NORTH, rat.getDirection());
        Assert.assertEquals(new Vector2d(0,4), rat.getPosition());
        rat.move(MoveDirection.RIGHT);
        assertEquals(MapDirection.EAST, rat.getDirection());
        Assert.assertEquals(new Vector2d(0,4), rat.getPosition());
        rat.move(MoveDirection.RIGHT);
        assertEquals(MapDirection.SOUTH, rat.getDirection());
        Assert.assertEquals(new Vector2d(0,4), rat.getPosition());
        rat.move(MoveDirection.BACKWARD);
        assertEquals(MapDirection.SOUTH, rat.getDirection());
        Assert.assertEquals(new Vector2d(0,4), rat.getPosition());
        rat.move(MoveDirection.FORWARD);
        assertEquals(MapDirection.SOUTH, rat.getDirection());
        Assert.assertEquals(new Vector2d(0,3), rat.getPosition());
        rat.move(MoveDirection.LEFT);
        assertEquals(MapDirection.EAST, rat.getDirection());
        Assert.assertEquals(new Vector2d(0,3), rat.getPosition());
        rat.move(MoveDirection.FORWARD);
        assertEquals(MapDirection.EAST, rat.getDirection());
        Assert.assertEquals(new Vector2d(1,3), rat.getPosition());

    }

    @Test
    public void input(){
        String[] commands = {"f","f", "b", "r" ,"l", "f", "r", "b"};
        MoveDirection[] directions = OptionsParser.parse(commands);
        RectangularMap testmap = new RectangularMap(5,5);
        Animal rat = new Animal(testmap, new Vector2d(2,2));
        rat.move(directions[0]);//f
        assertEquals(MapDirection.NORTH, rat.getDirection());
        assertEquals(new Vector2d(2,3), rat.getPosition());
        rat.move(directions[1]);//f
        assertEquals(MapDirection.NORTH, rat.getDirection());
        assertEquals(new Vector2d(2,4), rat.getPosition());
        rat.move(directions[2]);//b
        assertEquals(MapDirection.NORTH, rat.getDirection());
        assertEquals(new Vector2d(2,3), rat.getPosition());
        rat.move(directions[3]);//r
        assertEquals(MapDirection.EAST, rat.getDirection());
        assertEquals(new Vector2d(2,3), rat.getPosition());
        rat.move(directions[4]);//l
        assertEquals(MapDirection.NORTH, rat.getDirection());
        assertEquals(new Vector2d(2,3), rat.getPosition());
        rat.move(directions[5]);//f
        assertEquals(MapDirection.NORTH, rat.getDirection());
        assertEquals(new Vector2d(2,4), rat.getPosition());
        rat.move(directions[6]);//r
        assertEquals(MapDirection.EAST, rat.getDirection());
        assertEquals(new Vector2d(2,4), rat.getPosition());
        rat.move(directions[7]);//b
        assertEquals(MapDirection.EAST, rat.getDirection());
        assertEquals(new Vector2d(1,4), rat.getPosition());
    }

    @Test
    public void positionChanged() {
        GrassField map = new GrassField(5);
        Animal foo = new Animal(map, new Vector2d(0,0));
        GrassField map2 = new GrassField(6);
        map.place(foo);
        map2.place(foo);
        foo.addObserver(map2);
        map.moveAnimal(foo, MoveDirection.FORWARD);
        Assert.assertEquals(foo, map.objectAt(new Vector2d(0,1)));
        Assert.assertEquals(foo, map2.objectAt(new Vector2d(0,1)));
        map.moveAnimal(foo, MoveDirection.FORWARD);
        Assert.assertEquals(foo, map.objectAt(new Vector2d(0,2)));
        Assert.assertEquals(foo, map2.objectAt(new Vector2d(0,2)));
        foo.removeObserver(map2);
        map.moveAnimal(foo, MoveDirection.BACKWARD);
        Assert.assertEquals(foo, map.objectAt(new Vector2d(0,1)));
        Assert.assertEquals(foo, map2.objectAt(new Vector2d(0,2)));
    }
}