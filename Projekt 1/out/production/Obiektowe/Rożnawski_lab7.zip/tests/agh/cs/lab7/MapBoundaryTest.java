package agh.cs.lab7;

import agh.cs.lab2.Animal;
import agh.cs.lab2.Vector2d;
import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class MapBoundaryTest {

    @Test
    public void positionChanged() {
        MapBoundary mb = new MapBoundary();
        mb.add(new Animal(null, new Vector2d(2,5)));
        mb.add(new Animal(null, new Vector2d(4,-3)));
        Assert.assertEquals(new Vector2d(2,-3), mb.comptLowerLeft());
        Assert.assertEquals(new Vector2d(4,5), mb.comptUpperRight());
        mb.add(new Animal(null, new Vector2d(-1,6)));
        Assert.assertEquals(new Vector2d(-1,-3), mb.comptLowerLeft());
        Assert.assertEquals(new Vector2d(4,6), mb.comptUpperRight());
        mb.add(new Animal(null, new Vector2d(4,-3)));
        Assert.assertEquals(new Vector2d(-1,-3), mb.comptLowerLeft());
        Assert.assertEquals(new Vector2d(4,6), mb.comptUpperRight());
        mb.remove(new Animal(null, new Vector2d(4,-3)));
        Assert.assertEquals(new Vector2d(-1,5), mb.comptLowerLeft());
        Assert.assertEquals(new Vector2d(2,6), mb.comptUpperRight());

    }
}